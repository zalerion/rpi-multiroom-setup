Compiled with/for raspberry pi.
Copy to /usr/lib/ladspa/